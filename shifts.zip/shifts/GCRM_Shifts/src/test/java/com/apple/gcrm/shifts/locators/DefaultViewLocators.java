package com.apple.gcrm.shifts.locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;

public class DefaultViewLocators extends PageObject {

	
	
	
	@FindBy(xpath = "//*[@id='shiftApp']/div[1]/div[2]/div/div/header/section[1]/div[1]/div/div/span")
	public WebElement TimeZone;
	
	//Sidebar//
	
	@FindBy(xpath = "//aside[@id='tools-side-panel']")
	public 
	WebElement SideBar;
	
	@FindBy(xpath = "//button[@id='ToolsPanelBtn']")
	public WebElement Icon_RightAngle;
	
	@FindBy(xpath ="//span[@id='v-step-0']//img[@class='icon-img']")
	public WebElement Icon_AdditionHour;
	
	@FindBy(xpath = "//span[@id='v-step-1']//img[@class='icon-img']")
	public WebElement Icon_Flextime;
	
	@FindBy(xpath = "//span[@id='v-step-2']//img[@class='icon-img']")
	public WebElement Icon_Allowance;
	
	@FindBy(xpath = "//span[@id='v-step-3']//img[@class='icon-img']")
	public WebElement Icon_OpenSwap;
	
	@FindBy(xpath = "//button[@id='ToolsPanelBtn']")
	public WebElement Icon_Left_angle;
	
	
	///Checkbox
	
	@FindBy(xpath = "//input[@id='additional_hours']")
	public WebElement Checkbox_additional_hours;
	
	@FindBy(xpath = "//input[@id='flextime']")
	public WebElement Flextime_Checkbox;

	@FindBy(xpath ="//input[@id='group_allowance']")
	public WebElement Checkbox_group_allowance;
	
	@FindBy(xpath = "//input[@id='shifts_swap']")
	public WebElement Checkbox_Shifts_swap;
	
	
	
	/// UserSettingBtn
	@FindBy(xpath ="//button[@id='userSettingBtn']")
	public WebElement userSettingBtn;
	
	@FindBy (xpath = "//a[contains(text(),'Release Notes')]")
	public WebElement Link_ReleaseNote;
	
	@FindBy (xpath = "//a[contains(text(),'WFM Gather')]")
	public WebElement Link_WfmGather;
	
	@FindBy(xpath = "//a[contains(text(),'Shifts Gather')]")
	public WebElement Link_ShiftsGather;
	
	
	@FindBy(xpath = "//a[contains(text(),'New Feature Tour')]")
	public WebElement Link_NewFeatureTure;
	
	@FindBy(xpath = "//a[contains(text(),'Change User')]")
	public WebElement Link_ChangeUser;
	
	
	@FindBy(xpath = "//a[contains(text(),'Use Signed in User Account')]")
	public WebElement Link_UserSignAsccount;
	
	@FindBy (xpath = "//a[@class='user-dropdown-content popper-component']")
	public WebElement Link_LogOut;

	
	
	////TC 1.5 ////
	
	
	
	@FindBy (xpath = "//a[@id='weekLink']")
	public WebElement Link_Weekly;
	
	@FindBy (xpath = "//div[contains(text(),'Day')]")
	public WebElement Link_Day;
	
	@FindBy ( xpath = "//div[@class='single-day-header position-absolute font-weight-light']")
	public WebElement Text_DayName;
	
	@FindBy(xpath = "//div[@class='col time-column text-center my-auto all-day-label']")
	public WebElement Text_AllDay;
	
	@FindBy(xpath = "//div[@class='day-events-wrapper']")
	public WebElement Horizontal_line;
	
	@FindBy(xpath = "//div[@class='line-indicator']")
	public WebElement Red_line_currentTime;
	//span[@class='current-day-indicator']
	
	@FindBy (xpath = "//div[@class='calendar-header calendar-header tools-panel-present calendar-header d-none d-md-flex justify-content-between']//button[1]//img[1]")
	public WebElement Today_LeftAngle_icon;
	
	@FindBy(xpath = "//button[@class='today-btn pt-0 pb-0 pr-2 pl-2 d-none d-sm-block']")
	public WebElement Btn_Today;
	
	@FindBy(xpath = "//button[3]//img[1]")
	public WebElement Today_RightAngle_Icon;
	

	@FindBy(xpath = "//div[@class='mini-month-table day']")
	public WebElement Mini_Month_table;

	//No Of Days//
	
	@FindBy(xpath = "//span[@class='day-num heading-span order-2']")
	public WebElement No_Of_days; 
	
	
	@FindBy(xpath = "//span[@class='heading-span day-name']")
	public WebElement Name_Of_days; 
	
	@FindBy(xpath = "//*[@id='scheduleCalendarBody']/div[1]/div")
	public WebElement NO_of_cells;
	
	@FindBy(xpath = "//div[@id='dayeventsList-1578722400000']//div//div[@class='line-indicator']")
	public WebElement week_redline_CT;

	@FindBy (xpath = "//*[@id='shiftApp']/div[1]/div[2]/div/div/header/section[2]/div[2]/div[1]/h2/span/span[1]")
	public WebElement date_Month;
	
	@FindBy (xpath = "//*[@id='shiftApp']/div[1]/div[2]/div/div/header/section[2]/div[2]/div[1]/h2/span/span[2]")
	public WebElement date_day;
	
	@FindBy (xpath = "//*[@id='shiftApp']/div[1]/div[2]/div/div/header/section[2]/div[2]/div[1]/h2/span/span[3]")
	public WebElement date_year;
	
	
	@FindBy(xpath ="/html/body/div[1]/div[1]/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div[1]/div/table/tbody/tr/td")
	public WebElement Btn_selected_days;
	
	@FindBy(xpath ="/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/header[1]/section[2]/div[2]/div[1]/h2[1]/span[1]/span[1]")
	public WebElement Weekview_Month_name;
	
	@FindBy(xpath ="/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/header[1]/section[2]/div[2]/div[1]/h2[1]/span[1]/span[2]")
	public WebElement Weekview_Year_name;
	
	@FindBy(xpath ="/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/table[1]/tbody")
	public WebElement tbody;
	
	
	
	public List<WebElement> noOfDtCells()
	{
		///List<WebElement> li= getDriver().findElements(By.xpath("//button[@class='inner-cell mini-month-component month-day']"));
		List<WebElement> columns=tbody.findElements(By.tagName("td"));
		return columns;
	}
	
	public int no_of_cells()
	{
		List<WebElement> li= getDriver().findElements(By.xpath("//*[@id='scheduleCalendarBody']/div[1]/div"));
		return li.size();
	}
	
	public List<WebElement> day_Name_date()
	{
		List<WebElement> li= getDriver().findElements(By.xpath("//span[@class=\"heading-span day-name\"]"));
		return li;
	}
	public List<WebElement> date_number()
	{
		List<WebElement> li1= getDriver().findElements(By.xpath("//span[@class='day-num heading-span order-2']"));
		
		return li1;
	}
	
	
	/// T.C 1.8 Add segment btn
	
	@FindBy(xpath = "//button[@id='addSegmentBtn']")
	public WebElement Btn_Segment;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
