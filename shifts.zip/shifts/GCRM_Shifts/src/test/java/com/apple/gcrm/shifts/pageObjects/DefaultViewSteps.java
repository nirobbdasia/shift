package com.apple.gcrm.shifts.pageObjects;

import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import com.apple.gcrm.shifts.locators.DefaultViewLocators;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;

import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.logging.Logger;

import org.junit.Assert;
import org.openqa.selenium.WebElement;



public class DefaultViewSteps extends PageObject {
	
	GregorianCalendar  currentDate=new GregorianCalendar();	
	private final static Logger log = Logger.getLogger(DefaultViewSteps.class.getName());	
	Calendar calendar = Calendar.getInstance(TimeZone.getDefault());


	
	DefaultViewLocators locator;

	@Step("verify timezone")
	public void timeZone_verification(String exp_timezone) throws InterruptedException {
		System.out.println(getDriver().toString());
		Thread.sleep(10000);
		System.out.println("++++++++++++++++++++++++"+locator.TimeZone.getText());
		System.out.println("+++++++++++++++++++Excepected time zonw is "+exp_timezone);

		assertTrue("expected timezone:" + exp_timezone + " but actual time zone is:" + locator.TimeZone.getText(),
				locator.TimeZone.getText().contains(exp_timezone));

	}
	
	@Step("Verify Side bar is present")
	public void Sidebar_verification() throws InterruptedException {
		
		Thread.sleep(8000);
		
		boolean flag;		
		flag =locator.SideBar.isDisplayed();
		Assert.assertTrue("Verify Side bar is present",flag);		
		log.info("Verify Side bar is present"+flag);
		
	}
	
	@Step("Verify >> icon on side bar")
	public void Right_Angle_Icon_verification() {
		
		boolean flag;		
		flag =locator.Icon_RightAngle.isDisplayed();
		Assert.assertTrue("Verify >> icon on side bar",flag);
		
	}
	
	@Step("Verify Additional Hour icon present on side bar")
	public void Additional_hour_Icon_verification() {

		boolean flag;		
		flag =locator.Icon_AdditionHour.isDisplayed();
		Assert.assertTrue("Verify  AdditionHour icon on side bar",flag);
	}

	@Step("Verify  Flextime icon on side bar")
	public void Flextime_Icon_verification() {
		boolean flag;		
		flag =locator.Icon_Flextime.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
		
	}
	
	@Step("Verify Group Allowance icon present on side bar$")
	public void Groupallowance_Icon_verification() throws InterruptedException {
		Thread.sleep(4000);
		boolean flag;		
		flag =locator.Icon_Allowance.isDisplayed();
		Assert.assertTrue("Verify  Allowance_Icon icon on side bar",flag);
	}

	@Step("Verify Open Swap icon present on side bar")
	public void openswap_Icon_verification() {
		boolean flag;		
		flag =locator.Icon_OpenSwap.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}
	@Step("Click on >> icon and it should expand the bar")
	public void click_double_grater_Icon_verification() {
		
		getJavascriptExecutorFacade().executeScript("arguments[0].click();",locator.Icon_RightAngle);
	}
	
	@Step("Click on >> icon and it should expand the bar")
	public void Allfour_checkbox_verification() {
		
		boolean ahflag,ftflag,gaflag,osflag ;
		//if(locator.additional_hours_checkbox.isSelected())
		ahflag = locator.Checkbox_additional_hours.isSelected();
		ftflag = locator.Flextime_Checkbox.isSelected();
		gaflag = locator.Checkbox_group_allowance.isSelected();
		osflag = locator.Checkbox_Shifts_swap.isSelected();
		if((ahflag == false)&&(ftflag == false)&&(gaflag == false)&&(osflag == false)){		
			Assert.assertTrue("additional hourse check box: "+ahflag+" ,Flextime checkbox: "+ftflag+" ,group allownace checkbox "
					+ "is: "+gaflag+" ,Open swap check box: "+osflag ,true);		
		}
		else Assert.assertTrue("additional hourse check box: "+ahflag+" ,Flextime checkbox: "+ftflag+" ,group allownace checkbox "
				+ "is: "+gaflag+" ,Open swap check box: "+osflag ,false);				
		
		}
	
	
	@Step("<< icon should be presen")
	public void LeftAngel_Icon_verification() {
		
		boolean flag;		
		flag =locator.Icon_Left_angle.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}
	
	@Step("Click on << icon and it should collapse the side bar")
	public void click_leftAngle_Icon_verification() {
		
		getJavascriptExecutorFacade().executeScript("arguments[0].click();",locator.Icon_Left_angle);
	}

	public void userSettingBtn_verification() throws InterruptedException {
		Thread.sleep(8000);
		getJavascriptExecutorFacade().executeScript("arguments[0].click();",locator.userSettingBtn);
	}

	public void ReleaseNote_verification() {
		
		boolean flag;		
		flag =locator.Link_ReleaseNote.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void WFM_Gather_verification() {
		
		boolean flag;		
		flag =locator.Link_WfmGather.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Shifts_Gather_verification() {
		boolean flag;		
		flag =locator.Link_ShiftsGather.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
		
	}

	public void NeWFeature_verification() {
		boolean flag;		
		flag =locator.Link_NewFeatureTure.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
		
	}

	public void LogOut_verification() {
		boolean flag;		
		flag =locator.Link_NewFeatureTure.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void DayView_Varification() throws InterruptedException {
		Thread.sleep(3000);
		getJavascriptExecutorFacade().executeScript("arguments[0].click();",locator.Link_Day);
		
		Thread.sleep(3000);
		boolean flag;		
		flag =locator.Text_DayName.isEnabled();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
		
	}

	public void DayText_Vrdification() {
		
		 //GregorianCalendar  currentDate=new GregorianCalendar();	    
	     // String dayOfWeek2 = currentDate.getDisplayName(Calendar.DAY_OF_WEEK ,Calendar.LONG, Locale.getDefault());

		String Day = LocalDate.now().getDayOfWeek().name();
		String App_Day = locator.Text_DayName.getText();
		App_Day = App_Day.toUpperCase().trim();
		Assert.assertEquals(App_Day,Day);
		
	}

	public void AllDayText_Vrdification() {	
		boolean flag;		
		flag =locator.Text_AllDay.isDisplayed();
		Assert.assertTrue("Verify AllDay text is Available",flag);
	}

	public void Time_Horizontal_line_Vrdification() {
		
		boolean flag;		
		flag =locator.Horizontal_line.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Red_Horizontal_line_Vrdification() throws InterruptedException {
		Thread.sleep(3000);
		boolean flag;		
		flag =locator.Red_line_currentTime.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Left_Angle_icon_Vrdification() {
		
		boolean flag;		
		flag =locator.Today_LeftAngle_icon.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Right_Angle_icon_Vrdification() {
		boolean flag;		
		flag =locator.Today_RightAngle_Icon.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Today_link_Vrdification() {
		boolean flag;		
		flag =locator.Btn_Today.isDisplayed();
		Assert.assertTrue("Verify  Today btn",flag);
	}

	public void Mini_Calender_Vrdification() {
		boolean flag;		
		flag =locator.Mini_Month_table.isDisplayed();
		Assert.assertTrue("Verify  Today btn",flag);
	}

	public void Deafult_Varification() throws InterruptedException {
		
		Thread.sleep(8000);
		boolean flag;		
		flag =locator.Link_Weekly.isEnabled();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Page_seven_divition_Varification() {
		
		int actual_cells = 8;
		
		int Excepected_cells =locator.no_of_cells();
		Assert.assertEquals(Excepected_cells, actual_cells);
	}

	public void weekredline_currenttime_Varification() {
		boolean flag;		
		flag =locator.week_redline_CT.isDisplayed();
		Assert.assertTrue("Verify  Flextime icon on side bar",flag);
	}

	public void Date_Varification() {
		
		
		String datePrefix = DateTimeFormatter.ofPattern("MMMM dd,yyyy").format(LocalDate.now());
		String mon = locator.date_Month.getText();
		mon= mon.trim();
		String day = locator.date_day.getText();
		day = day.trim();
		String year = locator.date_year.getText();
		year = year.trim();
		String Date = mon+" "+day+year;		
		Assert.assertEquals(Date,datePrefix);
	}

	public void Selected_day_Verification() throws InterruptedException {
		Thread.sleep(4000);
		//System.out.println("++++++++++"+locator.s_day.getText());
		
		List<WebElement> li=locator.noOfDtCells();
		System.out.println(li.size()+"+++++++++++++++++++++++"+li);
		for (WebElement cell : li)
		{
		 String class_name = cell.getAttribute("class");
			System.out.println("+++++++++++++"+class_name+"+++++++++++++++++++++++++++++++++++++");
		}
			//int day = calendar.get(Calendar.DATE);
		//String day1 = String.valueOf(day);
		//Assert.assertEquals(selecteday, day1);	
		
	}

	public void Week_Date_format() {
		
		String Month = LocalDate.now().getMonth().name();
		int year = Calendar.getInstance().get(Calendar.YEAR);
		String year1 = Integer.toString(year);
		
		String App_Month_name = locator.Weekview_Month_name.getText();
		App_Month_name = App_Month_name.toUpperCase().trim();
		Assert.assertEquals(App_Month_name,Month);
		log.info("Current month is : "+Month+"and Application month is "+App_Month_name);
		
		String App_Year = locator.Weekview_Year_name.getText();
		App_Year = App_Year.trim();
		Assert.assertEquals(App_Year,year1);
		log.info("Current year is : "+year1+" and Application month is "+App_Year);

	}
	
	public void dayName_Date_format() {
		List<Object> excp_day_date = new ArrayList<Object>();
		String day = currentDate.getDisplayName(Calendar.DAY_OF_WEEK ,Calendar.LONG, Locale.getDefault());
		day = day.substring(0, 3);
		String date2 = String.valueOf(calendar.get(Calendar.DATE));
		String act_day_date = day+" "+date2;
		System.out.println(act_day_date);
		
		List<WebElement> day_name=locator.day_Name_date();
		List<WebElement> day_dt =locator.date_number();
		
		for (int i =0; i<day_name.size();i++)
		{
			excp_day_date.add(day_name.get(i).getText().trim()+" "+day_dt.get(i).getText().trim());
		}
		log.info("the dates of the whole week are in proper format: "+excp_day_date);
		Assert.assertTrue("the dates of the whole week are in proper format: "+excp_day_date, excp_day_date.contains(act_day_date));
		
	}	
}		

	
	
