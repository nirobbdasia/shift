package com.apple.gcrm.shifts.stepDefinitions;

import com.apple.gcrm.shifts.pageObjects.DefaultViewSteps;
import com.apple.gcrm.shifts.pageObjects.LoginSteps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import net.thucydides.core.annotations.ClearCookiesPolicy;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;

public class DefaultViewStepDef {
	@Managed(uniqueSession = true, clearCookies = ClearCookiesPolicy.Never)
	@Steps
	DefaultViewSteps defViewSteps;
	LoginSteps login;
	
	

	@Given("^User Launches the shifts tool as an advisor based in AMR$")
	public void launches_the_shifts_tool_as_an_advisor_based_in_AMR() throws Exception {
		login.navigate_to_shifts_default_view_page();

	}

	@Then("^Verify timezone \"([^\"]*)\" on the right hand corner$")
	public void verify_timezone_on_the_right_hand_corner(String exp_timezone) throws Exception {

		defViewSteps.timeZone_verification(exp_timezone);

	}

	@Then("^Verify Day, Week, Month and Year view are present$")
	public void verify_Day_Week_Month_and_Year_view_are_present() {
		
	}
	
	
	
	//////// TC:1.2 /////////////
	
	
	
	@Then("^Verify Side bar is present$")
	public void verify_Side_bar_is_present() throws InterruptedException {
		
		defViewSteps.Sidebar_verification();
	}


	@Then("^Verify >> icon on side bar$")
	public void verify_icon_on_side_bar() {
		
		defViewSteps.Right_Angle_Icon_verification();
	}

	@Then("^Verify Additional Hour icon present on side bar$")
	public void verify_Additional_Hour_icon_present_on_side_bar() {
	    
		defViewSteps.Additional_hour_Icon_verification();
	}

	@Then("^Verify Flextime icon present on side bar$")
	public void verify_Flextime_icon_present_on_side_bar() {
		defViewSteps.Flextime_Icon_verification();
	}

	@Then("^Verify Group Allowance icon present on side bar$")
	public void verify_Group_Allowance_icon_present_on_side_bar() throws InterruptedException {
	    
		defViewSteps.Groupallowance_Icon_verification();
	}

	@Then("^Verify Open Swap icon present on side bar$")
	public void verify_Open_Swap_icon_present_on_side_bar() {
	    
		defViewSteps.openswap_Icon_verification();
	}

	@Then("^Click on >> icon and it should expand the bar$")
	public void click_on_icon_and_it_should_expand_the_bar() {	    
		defViewSteps.click_double_grater_Icon_verification();
	}

	@Then("^All four icons should be present with boxes unchecked$")
	public void all_four_icons_should_be_present_with_boxes_unchecked() {
	    
		defViewSteps.Allfour_checkbox_verification();
	}

	@Then("^<< icon should be present$")
	public void icon_should_be_present() {
	   
		defViewSteps.LeftAngel_Icon_verification();
		
	}

	@Then("^Click on << icon and it should collapse the side bar$")
	public void click_on_icon_and_it_should_collapse_the_side_bar() {
		defViewSteps.click_leftAngle_Icon_verification();
	}

	
	///////1.3////////
	

@Then("^User Clicks on userSettingBtn_ to Expand the link list$")
public void user_Clicks_on_userSettingBtn__to_Expand_the_link_list() throws InterruptedException {
    
	defViewSteps.userSettingBtn_verification();
}

@Then("^User Verifies Release Notes link is present$")
public void user_Verifies_Release_Notes_link_is_present() {
    
	defViewSteps.ReleaseNote_verification();
}

@Then("^User Verifies WFM Gather link is present$")
public void user_Verifies_WFM_Gather_link_is_present() {
   
	defViewSteps.WFM_Gather_verification();
}

@Then("^User Verifies Shifts Gather link is present$")
public void user_Verifies_Shifts_Gather_link_is_present() {
    
	defViewSteps.Shifts_Gather_verification();
	
}

@Then("^User Verifies New Feature Tour link is present$")
public void user_Verifies_New_Feature_Tour_link_is_present() {
    
	defViewSteps.NeWFeature_verification();
}

@Then("^User Verifies Logout link is presen$")
public void user_Verifies_Logout_link_is_presen() {
	defViewSteps.LogOut_verification();
}


///T.C - 1.5 Day View////


@Then("^Verify that Week is default view once the user logs in$")
public void verify_that_Week_is_default_view_once_the_user_logs_in() throws InterruptedException {
   
	defViewSteps.Deafult_Varification();
}
@Then("^Click on Day Link to switch day view$")
public void click_on_Day_Link_to_switch_day_view() throws InterruptedException {
    
	defViewSteps.DayView_Varification();
}

@Then("^Verify Date is present in format MM DD, YYYY format on top left$")
public void verify_Date_is_present_in_format_MM_DD_YYYY_format_on_top_left() throws InterruptedException {
	defViewSteps.Date_Varification();
}

@Then("^Verify Day \\(name\\) is present under the date MM DD, YYYY format on top left$")
public void verify_Day_name_is_present_under_the_date_MM_DD_YYYY_format_on_top_left() {
    
	defViewSteps.DayText_Vrdification();
}

@Then("^Verify all-day is present under the Day \\(name\\) line$")
public void verify_all_day_is_present_under_the_Day_name_line() {
	defViewSteps.AllDayText_Vrdification();
}

@Then("^Verify the time horizontal lines are present on right hand side starting (\\d+) AM to (\\d+)PM$")
public void verify_the_time_horizontal_lines_are_present_on_right_hand_side_starting_AM_to_PM(int arg1, int arg2) {
    
	defViewSteps.Time_Horizontal_line_Vrdification();
}

@Then("^Verify the Red horizon line is present representing current time in right side of view of day$")
public void verify_the_Red_horizon_line_is_present_representing_current_time_in_right_side_of_view_of_day() throws InterruptedException {
	defViewSteps.Red_Horizontal_line_Vrdification();
}

@Then("^Verify left Angle link is present on right side (.*)$")
public void verify_left_Angle_link_is_present_on_right_side(String arg1) {
    
	defViewSteps.Left_Angle_icon_Vrdification();
}


@Then("^Verify > link is present on right side (.*)$")
public void verify_link_is_present_on_right_side(String arg1) {
   
	defViewSteps.Right_Angle_icon_Vrdification();
}

@Then("^Verify Today link is present on right side (.*)$")
public void verify_Today_link_is_present_on_right_side(String arg1) {
   
	defViewSteps.Today_link_Vrdification();
}

@Then("^Verify the calendar is present on right hand side of page$")
public void verify_the_calendar_is_present_on_right_hand_side_of_page() {
    
	defViewSteps.Mini_Calender_Vrdification();
}

@Then("^Verify the current date is highlighted with green circle on calendar$")
public void verify_the_current_date_is_highlighted_with_green_circle_on_calendar() throws InterruptedException {
    
	defViewSteps.Selected_day_Verification();
}
// 1.6
@Then("^Click on Week Link to switch Week view$")
public void click_on_Week_Link_to_switch_Week_view() throws InterruptedException {
    
	defViewSteps.Deafult_Varification();
		
}

@Then("^Verify the page is divided into seven columns representing days of week$")
public void verify_the_page_is_divided_into_seven_columns_representing_days_of_week(){
    
	defViewSteps.Page_seven_divition_Varification();
}

@Then("^Verify that current day of the week has date encircled with green$")
public void verify_that_current_day_of_the_week_has_date_encircled_with_green() {
    
	
}

@Then("^Verify the Red horizon line is present representing current time$")
public void verify_the_Red_horizon_line_is_present_representing_current_time() {
    
	defViewSteps.weekredline_currenttime_Varification();
}

@Then("^Verify Date is present in format MM YYYY format on top left$")
public void verify_Date_is_present_in_format_MM_YYYY_format_on_top_left() {
	defViewSteps.Week_Date_format();
}


@Then("^Verify the format of the day is Day Date$")
public void verify_the_format_of_the_day_is_Day_Date() {
	defViewSteps.dayName_Date_format();
}
//1.7

@Then("^Click on Create Segment\\+$")
public void click_on_Create_Segment() {
    
}

@Then("^Click on last element in the calendar date picker of 'select date'$")
public void click_on_last_element_in_the_calendar_date_picker_of_select_date() {
   
}

@Then("^Select start time from dropdown as '(\\d+):(\\d+) AM'$")
public void select_start_time_from_dropdown_as_AM(int arg1, int arg2) {
   
}

@Then("^Select End time from dropdown as '(\\d+):(\\d+)AM ' for the next day \\(last dropdown value\\)$")
public void select_End_time_from_dropdown_as_AM_for_the_next_day_last_dropdown_value(int arg1, int arg2) {
    
}

@Then("^Select 'Jury Duty' from segment code Dropdown options$")
public void select_Jury_Duty_from_segment_code_Dropdown_options() {
   
}

@Then("^click on 'create segment' button$")
public void click_on_create_segment_button() {
    
}

@Then("^Verify the below error should not be displayed:\"([^\"]*)\"$")
public void verify_the_below_error_should_not_be_displayed(String arg1) {
  
}

@Then("^close the popup window$")
public void close_the_popup_window() {
   
}




































}
