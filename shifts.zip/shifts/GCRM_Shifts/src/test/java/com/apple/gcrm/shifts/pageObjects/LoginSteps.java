package com.apple.gcrm.shifts.pageObjects;

import java.util.logging.Logger;

import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.util.EnvironmentVariables;

public class LoginSteps extends PageObject {
	public EnvironmentVariables env;
	public static Logger log = Logger.getAnonymousLogger();

	@Step
	public void navigate_to_shifts_default_view_page() throws InterruptedException {

		String url = EnvironmentSpecificConfiguration.from(env).getProperty("homepageUrl");
		openAt(url);

		log.info("opening shifts application:" + url);

		getDriver().manage().window().maximize();

	}

}
