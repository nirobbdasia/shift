package com.apple.gcrm.shifts.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(plugin = {
		"pretty" }, glue = "com.apple.gcrm.shifts.stepDefinitions", features = "src/test/resources/features",dryRun = false,tags= {"@A"}	)
public class DefaultViewRunner {

}
